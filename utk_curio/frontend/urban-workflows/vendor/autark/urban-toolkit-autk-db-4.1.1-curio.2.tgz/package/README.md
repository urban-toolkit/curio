<div align="center">
  <img src="../logo.png" alt="Autark Logo" height="150"/></br>

  <h1>@urban-toolkit/autk-db</h1>

  <br>
  <p><strong>In-browser spatial database for urban datasets.</strong></p>

  <p>
    <a href="https://arxiv.org/abs/2604.20759">Paper</a> ·
    <a href="https://autarkjs.org/">Website</a>
  </p>  
</div>
<br>

## Autark toolkit

**Autark** is a serverless, modular TypeScript toolkit for prototyping urban visual analytics systems entirely in the browser. It supports client-side workflows for loading, storing, querying, joining, computing, and visualizing physical and thematic urban data using standard formats such as OpenStreetMap, GeoJSON, GeoTIFF, and CSV.

The toolkit is available as the umbrella package `@urban-toolkit/autk` or as individual modules:

* `@urban-toolkit/autk-db`: In-browser spatial database for urban datasets.
* `@urban-toolkit/autk-compute`: WebGPU computation engine for analytical and render-based pipelines.
* `@urban-toolkit/autk-map`: WebGPU-based 2D/3D vector map visualization library.
* `@urban-toolkit/autk-plot`: D3.js-based plotting library for linked urban data views.

## @urban-toolkit/autk-db

`@urban-toolkit/autk-db` provides an in-browser spatial database built on DuckDB-Wasm and its spatial extension. It helps applications load urban datasets, organize them into workspaces, run spatial joins and custom SQL queries, and export layers as GeoJSON for use with `autk-map`, `autk-plot`, or other tools.

### Basic usage

```ts
import { AutkDb } from '@urban-toolkit/autk-db';

const db = new AutkDb();
await db.init();

await db.loadGeojson({
  outputTableName: 'buildings',
  geojsonObject: buildingsGeojson,
  layerType: 'buildings',
});

const buildings = await db.getLayer('buildings');
console.log(db.tables, buildings);
```

### Workspace CRS and precision

Every workspace defaults to `{ coordinateFormat: 'EPSG:3395', precisionGrid: 0.01 }`; the grid is one centimetre because the default CRS is metric. Inspect it with `db.getWorkspaceConfiguration()`.

To use another CRS, configure **both** values atomically when creating or selecting an empty workspace. Autark refuses a CRS/grid change after the workspace has tables, because existing geometries cannot be silently reprojected.

```ts
await db.setWorkspace('geographic', {
  coordinateFormat: 'EPSG:4326',
  precisionGrid: 1e-7,
});
```

`precisionGrid` is expressed in the workspace CRS units. It must be a finite positive value; do not reuse `0.01` for geographic degrees.

Managed vector imports (OSM, GeoJSON, spatial CSV/JSON), updates and vector tables created by `rawQuery` are normalized with `ST_ReducePrecision` **after** transformation to the workspace CRS. Crop/union results and coastal masks use the same grid. This is a behavior change: coordinates and polygon ring order may change; byte-identical geometry round-trips are no longer promised. Building collections are normalized one top-level part at a time, preserving component order, `geometryIndex` and attributes without dissolving overlapping parts. A grid that collapses an input geometry or an entire indexed building part rejects the operation; choose a finer grid. Small holes/components may disappear within the configured tolerance. Raster grids retain their own resolution.

Spatial crops are transactional and do not retry. GeoJSON loading rolls back the new/replaced table and its metadata if normalization or cropping fails. The #106 Back Bay surface/park round-trip is covered by a local regression fixture in `autk-db/test/workspace-precision.test.ts`.

### OpenStreetMap areas, bounding boxes and surface

Both Overpass and local `.osm.pbf` loading accept named administrative areas or a WGS84 bounding box:

```ts
await db.loadOsm({
  queryArea: { bbox: [-74.019, 40.700, -74.003, 40.714] }, // west, south, east, north
  // pbfFileUrl: '/data/lower_mnt.osm.pbf', // optional: read a local extract instead of Overpass
  autoLoadLayers: { layers: ['buildings', 'roads', 'water'] },
});
```

Named queries use `queryArea: { geocodeArea: 'Illinois', areas: ['Golf'] }`. Both sources match exact named OSM boundaries (including `boundary=administrative` and `boundary=place`) with at least one member node inside the named region, not just its rectangular extent. Overpass derives each thematic area from the same scoped boundary relation via `map_to_area`. PBF reconstructs the region's polygons, including holes and disconnected components, before selecting the requested boundaries. If the PBF lacks usable region geometry (missing, incomplete or invalid), loading continues with a clear warning and matches only the exact boundary names in `areas`. This fallback may include homonymous areas elsewhere in the extract; use a complete extract or `queryArea.bbox` when that ambiguity matters. Missing requested area names still cause an error. The small gallery `lower_mnt.osm.pbf` uses this warned fallback because its New York boundary is incomplete.

Boxes require four finite WGS84 coordinates within geographic limits, with west < east and south < north; antimeridian crossings are unsupported. Overpass spatial selectors acquire candidates, not an exhaustive geometric intersection query. PBF cannot recover relation members absent from the extract.

**Surface is always constructed**, whether requested or not. Its base geometry is the named administrative region or the bbox rectangle. For named queries, Overpass obtains the complete `geocodeArea` boundary and independently collects all `natural=coastline` ways in its **bbox**, including neighboring land regardless of jurisdiction. Building tiles and thematic selection still use `areas`, not the geocode bbox. PBF uses the same classification pipeline, reading all needed ways/nodes from that file without network supplementation. A PBF must contain a usable geocode boundary and complete coastline coverage of its bbox; containing only the requested areas or the administrative relation is insufficient. If region scoping falls back because the geocode is incomplete, no coastal water is inferred.

Coastline direction (land on the left), connected edges and closed/consistently classified faces define land inside the collection bbox. Surface intersects that land with the query's base geometry. Requested `water` retains explicit OSM water polygons and adds **bbox(areas) minus classified land**, bounded to the classified extent. This context can extend outside the administrative area but never outside its bbox, and protects all mapped land, including neighboring islands. Generated water has a negative internal ID and `properties.generated = 'coastline'`, `water = 'sea'`; it is not an OSM source object and is omitted from `getLayer(..., { osmElements: true })`. Filter this marker out when an analysis must use only administrative OSM features. An entirely inland areas bbox produces no generated coastal water; lakes/rivers still come from explicit OSM features.

Missing, incomplete, ambiguous or invalid coastlines produce a clear `console.warn`, retain the full base surface and **never turn unknown land into sea**. This includes a bbox with no coastline: absence alone cannot distinguish all-land from all-sea. Validation detects broken references/networks, but cannot certify that an entire island was not omitted from a truncated extract; use a coherent, sufficiently complete regional snapshot. Coastline mask coordinates are quantized to 1e-10 degrees for endpoint matching; projected masks, generated water and loaded vectors use the workspace precision grid. Area-layer intersection crops retain only polygons, preventing linear remnants from rendering as filled areas.

Both named-area and bbox imports clip roads/parks/water by this surface, even if `surface` is omitted from `layers`. Roads crossing the query boundary or coastal land mask are cropped, including bridges and other roads over water. OSM building parts remain uncut: only parts fully covered by the bbox and surface are retained; partially contained or external parts are discarded. Grouped buildings retain their contained parts with updated geometry indices and OSM element metadata; a building is removed only when no parts remain. Parts touching the boundary but fully contained are retained. This changes the previous optional-surface behavior and can reduce results for named areas. An omitted surface is retained internally for subsequent workspace constraints but excluded from `getLayersMetadata()` and per-layer load timings; it remains inspectable through `getTablesMetadata()`/`getLayer()`. Include `surface` to expose it normally. Overpass caches use `v5` for named queries and `v4` for bbox queries, rejecting older payloads that mixed coastlines into thematic responses or classified only the areas extent.

BBox gallery examples: [`osm-layers-api-bbox`](../gallery/src/autk-map/osm-layers-api-bbox.ts) and [`osm-layers-pbf-bbox`](../gallery/src/autk-map/osm-layers-pbf-bbox.ts).

### Typed OpenStreetMap tag sets

Overpass loads custom tag-selected layers beside the standard themes. **Each set requires one `type`** and creates only `<outputTableName>_<name>_<type>`; there is no automatic three-layer split or geometry conversion.

```ts
await db.loadOsm({
  queryArea: { bbox: [-74.019, 40.700, -74.003, 40.714] },
  autoLoadLayers: { layers: [] }, // Tag-only load; surface is still mandatory and internal.
  tagSets: [{
    name: 'cafes',
    type: 'points',
    tags: [{ key: 'amenity', value: 'cafe' }],
  }],
});
const cafes = await db.getLayer('table_osm_cafes_points', { osmElements: true });
```

Filters within a set use **OR**: `{ key: 'shop' }` matches key presence, while `{ key: 'amenity', value: 'school' }` matches an exact value, never a regex. `points` accepts nodes only; a school mapped only as an area is not converted into a centroid. `polylines` accepts open ways and closed linear ways. `polygons` accepts closed area ways and `type=multipolygon` relations; other relation types are ignored. A closed way is linear when `area=no`, or when `highway`, `barrier`, `railway` or `waterway` is present without `area=yes`; other closed ways default to areas. This is a limited classification policy, not a universal OSM tag classifier.

All tag sets are filtered/cropped against the same mandatory, optionally coastal **surface**: external points are removed, lines/polygons are clipped, and empty or wrong-dimensional intersection components are discarded. Relation members outside the area are downloaded for assembly, but their external geometries do not survive clipping as independent features. Results use the workspace CRS and precision grid, including element export. Invalid or incomplete ways are skipped with a warning; relations use the existing ring assembler and its missing-member warnings/limitations. Database failures and precision-grid collapse errors still propagate.

A set with no features after clipping has no table or timings entry. Reload replaces the set's layer, removes obsolete geometry-family tables for that same set, and restores its old table/metadata if processing fails. Sets omitted from a later call are not deleted. Per-set table replacement and clipping are transactional; the entire OSM import remains non-atomic. Tag timing entries carry `tagSet` and a **final, post-clipping** `featureCount`.

Tag sets are **Overpass-only**; combining them with `pbfFileUrl` throws before acquisition. Validation allows at most 8 sets, unique lowercase identifier names (up to 32 characters), and 1–64 filters per set. Keys use `[A-Za-z0-9][A-Za-z0-9_:.-]*` (up to 255 characters); values are 1–255 characters without control characters. One extra Overpass request acquires all sets, with selectors restricted to requested element families. Cache keys include geometry types and canonical filters, not set names/order; traditional full-data cache entries never satisfy tag requests.

Gallery example, based on `osm-layers-pbf.ts` but using Overpass: [`osm-tag-sets`](../gallery/src/autk-map/osm-tag-sets.ts). Open `/src/autk-map/osm-tag-sets.html` to see food points, footway lines and playground polygons with the standard Lower Manhattan layers.

### Building features and spatial joins

With `layerType: 'buildings'`, each feature is stored/exported as one GeometryCollection of its original parts, normalized independently to the workspace precision grid. Use `properties.parts[].geometryIndex` for per-part attributes. Distinct GeoJSON features remain distinct even when they overlap. OSM `type=building` relations associate original member ways and multipolygons without generating a duplicate geometry, including disconnected/untagged members. A member with a role other than `outline`, `part`, `outer` or empty, such as `roof` or `column`, is a part when the building layer selects it by its own `building` or `building:part` tags; any other such member (a roof `ridge` line, an untagged area) adds nothing and never becomes a building of its own. Orphan ways tagged `building:part` (except `no`) are associated with a relation only when their whole geometry is covered by an original outline of exactly one usable surface relation. Outline roles are authoritative; empty/outer-role members qualify only when tagged as whole buildings, not parts. Holes are respected, explicit ownership is never overridden, and inferred parts do not become outlines. Ambiguous containment warns and leaves the part unassociated; partial overlap and independent buildings do not qualify. Remaining unassociated ways retain intersection-based clustering. General relation attributes are inherited by parts, whose own tags take precedence. `properties.osmRelation` retains the relation ID (string), membership/roles (`type: 'relation'` marks a multipolygon member) and original tags; optional `osmRelation.inferredParts` records inferred IDs and `method: 'outline-containment'` separately from original members. Feature.id normally remains the minimum source part ID (negative internal keys disambiguate rare way/relation ID collisions; use the element export for OSM identity); unusable/missing outline or part geometry or shared ownership causes a console warning and omission of the whole affected relation, avoiding partial buildings. Conflicting roles and relations with no members to draw also warn and skip the affected relation plus all its direct way members; unrelated buildings continue loading. Invalid membership is not converted into a partial building or standalone member features. Explicit `location=underground` parts and relations are excluded from this surface building layer with a console warning, before spatial clustering; above-ground parts of mixed buildings remain. Height zero, negative `layer` and basement-level tags alone do not trigger exclusion. There is no union, convex hull or persistent `agg_geometry`. Both PBF and Overpass collect `type=building` relations, their way members and multipolygons tagged `building` or `building:part` (a multipolygon member without those tags is missing); Overpass uses versioned cache keys so older responses lacking these relations are not reused. Source parity requires the same OSM snapshot and complete relation geometry: a local extract cannot reconstruct coordinates for members absent from the PBF.

Public GeoJSON IDs are separate from internal numeric row IDs:

```ts
await db.updateTable({
  tableName: 'buildings', strategy: 'update',
  idColumn: 'geojson_id', data: updatedBuildings,
});
```

Keep each input Feature.id for this update; missing IDs are rejected. `idColumn: 'id'` deliberately addresses an internal row key instead.

Spatial joins count matched features once, not individual parts. Aggregate paths remain `properties.sjoin.count.points` and similar. A join without aggregation now keeps one root feature with `properties.sjoin.matches: [{ id?, properties }]`; no matches gives an empty array. Nonaggregated named fields become arrays. NEAR still defaults to centroid distance; `near.useCentroid: false` uses minimum component distance.

GeoJSON building import/update rejects invalid geometry without repair. OSM buildings instead log invalid/missing/empty/non-polygonal geometry with `console.warn` and skip the affected feature, continuing the import without repair. Database/transaction errors are not swallowed. OSM bbox and named-area imports discard parts not fully contained in the surface instead of cutting them, preserving grouped buildings with surviving parts; other workspace polygon crop behavior remains. Old per-part OSM tables, custom SQL, flattened join consumers and stored window IDs need migration/reload.

Tests from the repository root: `npm test -- autk-db/test` (real DuckDB-WASM in Node; spatial extension access required, no Playwright).

### Exporting individual OSM elements

The default `getLayer(name)` is unchanged: buildings remain consolidated GeometryCollections. For an analytical download with one feature per retained OSM element, request the opt-in mode:

```ts
import type { GetLayerOptions } from '@urban-toolkit/autk-db';

const options: GetLayerOptions = { osmElements: true };
const elements = await db.getLayer('table_osm_buildings', options);
// Feature.id: 'way/201' or 'relation/201' (separate OSM namespaces).
// Properties: own source tags + osm_type, numeric osm_id, and building_id for buildings.
// Geometry: the current Polygon/MultiPolygon component, not an aggregated collection.

const parks = await db.getLayer('table_osm_parks', options);
const roads = await db.getLayer('table_osm_roads', options);
```

Two touching house ways can export as two features with their own heights and a shared `building_id`. Multipolygon relations with their own stored geometry export as `relation/...`. Ownership-only `type=building` relations do not generate duplicate geometry/features; their members retain the association via `building_id`. Treat building IDs as opaque grouping keys, not OSM identities. Results are ordered by building ID (buildings), then OSM type and numeric ID.

The mode preserves source tags separately from common/inherited building attributes and from added analytical properties. Generated `osm_type`/`osm_id` and building association fields take precedence over source tags with those names. Internal layer markers are removed from feature properties; root layer metadata and workspace bbox follow ordinary export.

Geometries are the currently stored, CRS-transformed, precision-normalized and filtered/cropped geometries, not the original raw OSM coordinates. Buildings remain whole components; roads/parks/water retain the existing crop behavior. Invalid or underground building elements omitted by the import are not resurrected.

Overpass and PBF imports retain source identity/tags/component indices in the internal `__autk_osm_elements` JSON column, without a second geometry copy. Surface, rasters, non-OSM tables, legacy tables without provenance and derived building tables missing component/association metadata fall back to ordinary export. Do not infer OSM identity from `refs` or user-supplied `osm_id` tags. User `updateTable` operations conservatively invalidate element provenance for the entire layer; reload OSM to restore this mode. Raw SQL that alters geometries while retaining provenance must not claim that stale provenance describes the derived layer.

### JSON geometry loading

`loadJson` can import plain JSON records or materialize geometry during load using the same geometry options supported by `loadCsv`:

- `geometryColumns: true` → reads default `Latitude` / `Longitude` fields as points
- `{ latColumnName, longColumnName, coordinateFormat? }` → reads explicit coordinate fields as points
- `{ wktColumnName, coordinateFormat? }` → parses WKT geometry and infers the returned layer family

```ts
const parcels = await db.loadJson({
  outputTableName: 'parcels',
  jsonObject: [
    { id: 1, wkt: 'POLYGON((-43.3 -22.9, -43.2 -22.9, -43.2 -22.8, -43.3 -22.8, -43.3 -22.9))' },
  ],
  geometryColumns: { wktColumnName: 'wkt' },
});

console.log(parcels.type); // 'polygons'
```

### API summary

* `new AutkDb()`: Creates an isolated database controller.
* `init()`: Initializes DuckDB-Wasm and loads the spatial extension.
* `tables`: Lists tables registered in the current workspace.
* `setWorkspace(name, configuration?)`, `getWorkspaces()`, `getCurrentWorkspace()`, `getWorkspaceConfiguration()`: Manage isolated database schemas and their paired CRS/precision-grid configuration.
* `loadOsm(params)`: Loads OpenStreetMap data from Overpass API or PBF-backed workflows.
* `loadCsv(params)`, `loadJson(params)`: Imports tabular or JSON data.
* `loadGeojson(params)`: Imports custom GeoJSON layers.
* `loadGeoTiff(params)`, `getGeoTiffLayer(tableName)`: Imports and exports GeoTIFF-derived raster layers.
* `getLayer(layerTableName, options?)`: Exports a layer table as a GeoJSON `FeatureCollection`; `GetLayerOptions.osmElements` opts into individual OSM elements when preserved provenance is available.
* `getBoundingBoxFromLayer(layerName)`: Computes a layer bounding box.
* `getTableData(params)`: Reads table data for inspection or UI display.
* `updateTable(params)`: Updates a table using the supported update strategies.
* `spatialQuery(params)`: Runs spatial joins and aggregations from a vector root against vector features or compact raster cell centers.
* `rawQuery(params)`: Executes custom SQL against the current workspace.
* `buildHeatmap(params)`: Creates a grid internally and builds aggregated heatmap outputs.
* `removeLayer(tableName)`: Drops a table from the current workspace.

## Spatial joins with compact rasters

Use a raster loaded by `loadGeoTiff()` or produced by `buildHeatmap()` as `tableJoinName`, with a vector `tableRootName`. The root is updated in place, preserving its feature identities and geometry.

Each decoded cell is an implicit point at its center, not a pixel-area polygon. `INTERSECT` includes centers on polygon boundaries; `near` defaults to centroid-to-center distance and `useCentroid: false` measures distance to the entire root geometry. Distances use workspace CRS units. Centers are transformed individually from the source grid and evaluated on the workspace precision grid; the raster arrays retain their resolution.

```ts
await db.spatialQuery({
  tableRootName: 'roads', tableJoinName: 'lst',
  near: { distance: 1000 },
  groupBy: [{ column: 'band_1', aggregateFn: 'avg' }],
});
```

All existing aggregates, simple matches, column collections and numeric normalization use the same output contract as vector joins. Non-finite/NoData band values become SQL NULL: numeric aggregates and `count(band)` ignore them. `count('*')` counts matched cell centers, even when a band has NoData. Compact rasters are not supported as the root of an in-place join.

Only requested bands cross into DuckDB, as one row of packed numeric arrays. Candidate row/column ranges come from the implicit grid index; no per-pixel geometry table or spatial index is persisted. Inverse-bbox pruning supports identical CRSs and axis-monotone WGS84/Mercator transformations within their domains. Other CRS transformations conservatively scan the full grid to avoid excluding valid centers; these can be more expensive. GeoTIFF grids must be axis-aligned; rotated/sheared grids are rejected rather than incorrectly sampled as their bbox. Resampled rasters use the decoded grid's centers and resolution.

Join keys include literal dots: JavaScript reads `properties.sjoin.avg['lst.band_1']`; SQL uses `json_extract(properties, '$.sjoin.avg."lst.band_1"')`. Autark's shared `valueAtPath` also resolves `sjoin.avg.lst.band_1` for map, plot and compute bindings.

## Resources

- [Documentation](https://autarkjs.org/introduction.html)
- [Examples](https://autarkjs.org/gallery/)
- [Use Cases](https://autarkjs.org/usecases/)
