Built-up surface, one tile.
