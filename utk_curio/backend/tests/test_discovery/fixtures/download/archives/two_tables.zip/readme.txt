two tables
